<?php
include 'db.php';
session_start();

if (isset($_POST['login'])) {
    $username = $conn->real_escape_string(trim($_POST['username']));
    $password = $_POST['password'];

    $sql = "SELECT users.*, stores.name as store_name FROM users
            LEFT JOIN stores ON users.store_id = stores.id
            WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['store_id'] = $user['store_id'];
        $_SESSION['store_name'] = $user['store_name'];
        echo "<p>Login successful! Welcome, " . $user['username'] . " (" . $user['role'] . ") at store: " . $user['store_name'] . "</p>";
    } else {
        echo "<p>Invalid credentials. Please try again.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body { font-family: Arial, sans-serif; }
        form { margin: 20px 0; }
        label { display: inline-block; width: 150px; }
        input { padding: 5px; }
    </style>
</head>
<body>
    <h2>Login</h2>
    <form method="POST">
        <label for="username">Username:</label>
        <input type="text" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="text" name="password" required><br><br>

        <input type="submit" name="login" value="Login">
    </form>
</body>
</html>
